import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dasboard-details',
  templateUrl: './dasboard-details.component.html',
  styleUrls: ['./dasboard-details.component.css']
})
export class DasboardDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
