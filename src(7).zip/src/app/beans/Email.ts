

export interface Email {
    event: string;
    email: string;
    }