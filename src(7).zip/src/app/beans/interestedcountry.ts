export interface InterestedCountry {
    countryID: number;
    ccid: number;
    countriesIntrested: string;
}