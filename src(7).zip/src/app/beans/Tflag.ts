

export enum Tflag {
    VIEW, EDIT ,PLACE_QUOTE,
}