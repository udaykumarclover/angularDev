import * as $ from './jquery.min';
import * as m from './bootstrap.min'